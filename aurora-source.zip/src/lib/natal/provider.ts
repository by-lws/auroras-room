import { NatalError, normalizePlanets, resolveBirthTime, validateBirth } from "./core.ts";

// Server-only adapter. Intentionally not exposed as a paid/public calculation.
export async function calculateProviderPlanets(value: unknown, token: string, fetcher: typeof fetch = fetch) {
  const birth = validateBirth(value);
  const resolved = resolveBirthTime(birth);
  if (resolved.precision !== "minute") throw new NatalError("HISTORICAL_REVIEW", "Историческая дата требует проверки часового пояса.");
  if (!token) throw new NatalError("NOT_CONFIGURED", "Расчётный сервис ещё не подключён.");
  const [year, month, day] = birth.date.split("-").map(Number);
  const [hour, min] = birth.time!.split(":").map(Number);
  let response: Response;
  try {
    response = await fetcher("https://json.astrologyapi.com/v1/western_horoscope", {
      method: "POST", cache: "no-store", signal: AbortSignal.timeout(15000),
      headers: { "Content-Type": "application/json", "x-astrologyapi-key": token },
      body: JSON.stringify({ day, month, year, hour, min, lat: resolved.place.lat, lon: resolved.place.lon, tzone: resolved.offsetHours, house_type: "placidus", is_asteroids: false }),
    });
  } catch { throw new NatalError("PROVIDER_UNAVAILABLE", "Расчёт временно недоступен. Пример не заменяет персональную карту."); }
  if (!response.ok) throw new NatalError("PROVIDER_UNAVAILABLE", "Расчётный сервис не смог обработать запрос.");
  try { return { placements: normalizePlanets(await response.json()), utc: resolved.utc, zone: resolved.place.zone, provider: "astrologyapi-v1", houseSystem: "placidus" as const }; }
  catch (e) { if (e instanceof NatalError) throw e; throw new NatalError("PROVIDER_SCHEMA", "Не удалось проверить ответ расчётного сервиса."); }
}
