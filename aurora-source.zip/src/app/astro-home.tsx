import Image from "next/image";
import Link from "next/link";
import { AutomaticLinks, CatalogCards } from "./astro-components";
import { SiteHeader } from "./components/site-header";
import { SiteFooter } from "./components/site-footer";
import "./astro.css";

const faq = [
  ["Это личная работа Авроры?", "Только карточки с пометкой «Лично с Авророй». Экспресс-натал и один город — автоматические продукты."],
  ["Если время неизвестно?", "Экспресс исключает дома, ASC/MC и зависимые выводы. Автоматическая релокация требует точного времени; можно выбрать личную консультацию."],
  ["Когда будет доступен результат?", "После запуска — сразу после серверного подтверждения оплаты. Сейчас показаны только учебные примеры."],
  ["Где отзывы?", "Отзывы добавим только с разрешения авторов. Фиктивные истории и отзывы не публикуем."],
];

export function AstroHome() {
  return <main className="astroPage astroHome">
    <section className="hero"><SiteHeader /><div className="shell astroHero">
      <div><p className="eyebrow">AURORA’S ROOM <span> / </span> АСТРОЛОГИЯ</p>
        <h1>Всё начинается<br /><em>с тебя.</em></h1>
        <p>Услышать себя. Увидеть свои сильные стороны. Найти свой путь — через карту рождения и бережный разговор с Авророй.</p>
        <AutomaticLinks />
        <div className="editorialSignature"><span aria-hidden="true">✧</span><p>Не предсказание судьбы.<br/>Пространство для знакомства с собой.</p></div>
      </div>
      <div className="editorialPortrait"><span className="editorialPortraitTop">ЧЕЛОВЕК МЕЖДУ НЕБОМ И ЗЕМЛЁЙ</span><div className="editorialPortraitFrame"><Image src="/aurora.jpg" alt="Аврора — автор Aurora’s room" fill priority sizes="(max-width: 760px) 80vw, 410px"/></div><div className="editorialSeal" aria-hidden="true">a<span>aurora’s room</span></div><Image className="editorialCat" src="/aurora-cat.png" alt="" width={84} height={84}/><p className="editorialPortraitCaption"><span>Аврора</span><i>к себе, с любовью</i></p></div>
    </div></section>
    <nav className="astroQuickNav shell" aria-label="Выбор формата"><a href="#express">Быстрый экспресс <span>↘</span></a><a href="#personal">Лично с Авророй <span>↘</span></a></nav>
    <section className="shell astroSection" id="express"><p className="eyebrow">01 / АВТОМАТИЧЕСКИЕ ФОРМАТЫ</p><h2>Первый взгляд<br/><em>на вашу карту</em></h2><p className="astroSectionIntro">Небольшой отчёт для знакомства с собой. Состав и цена известны заранее.</p><p className="astroNotice">Сейчас доступны учебные примеры. Приём платежей ещё не открыт.</p><CatalogCards kind="automatic" /></section>
    <section className="shell astroSection" id="personal"><p className="eyebrow">02 / ЛИЧНО С АВРОРОЙ</p><h2>Глубже, чем<br/><em>готовые ответы</em></h2><p className="astroSectionIntro">Выберите свою тему. Формат и сроки Аврора уточнит с вами лично.</p><CatalogCards kind="personal" /></section>
    <section className="astroJourney"><div className="shell astroSection"><p className="eyebrow">ПРОСТО И БЕРЕЖНО</p><h2>Ваш следующий шаг</h2><ol><li><span>01</span><div><h3>Выберите формат</h3><p>Краткий автоматический отчёт или личная консультация.</p></div></li><li><span>02</span><div><h3>Подготовьте данные</h3><p>Дату, место и время рождения. Если время неизвестно — так и укажите.</p></div></li><li><span>03</span><div><h3>Посмотрите пример</h3><p>Для экспресса доступен учебный результат. Для личной работы — анкета обращения к Авроре.</p></div></li></ol></div></section>
    <section className="shell astroSection"><h2>Об Авроре</h2><p className="astroLead">Здесь карты, самоисследование и личная работа встречаются с вниманием к вашей реальной ситуации. Автоматический отчёт не заменяет общения с Авророй.</p><Link className="textLink" href="/about">Познакомиться с Авророй →</Link></section>
    <section className="shell astroSection"><h2>Перед началом</h2>{faq.map(([q,a]) => <details key={q}><summary>{q}</summary><p>{a}</p></details>)}<div className="astroLinks"><Link href="/contacts">Контакты</Link><Link href="/privacy">Конфиденциальность</Link><Link href="/terms">Условия покупки</Link></div></section>
    <SiteFooter />
    <nav className="astroMobileDock" aria-label="Быстрый переход"><Link href="/natal">Экспресс-карта <span>↗</span></Link><Link href="/personal">Личный разбор <span>↗</span></Link></nav>
  </main>;
}
