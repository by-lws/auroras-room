import {SiteHeader} from "../components/site-header";
import {SiteFooter} from "../components/site-footer";
import {CatalogCards} from "../astro-components";
import "../astro.css";
export const metadata={title:"Личные разборы с Авророй",description:"Соляр, совместимость, полный натал и другие форматы личной работы — только по записи."};
export default function Personal(){return <main className="astroPage"><div className="astroTop"><SiteHeader/></div><section className="shell astroSection"><p className="eyebrow">ЛИЧНО С АВРОРОЙ / ПО ЗАПИСИ</p><h1 className="astroTitle">Глубже, чем<br/>автоматический отчёт.</h1><p className="astroLead">Выбирайте личный формат. Аврора уточняет запрос, срок и оплату в общении с вами. Ни одна услуга этого каталога не запускает автоматический расчёт.</p><CatalogCards kind="personal"/></section><SiteFooter/></main>;}
