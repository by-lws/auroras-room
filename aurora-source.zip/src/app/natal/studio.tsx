"use client";
import Image from "next/image";
import { useState } from "react";
import { auditReport, buildAspectReadings, buildReport, calculateAspects, demoChart, NatalError, places, planetNames, resolveBirthTime, validateBirth, zodiac } from "../../lib/natal/core";

const report = buildReport(demoChart);
const aspects = calculateAspects(demoChart.placements);
const aspectReadings = buildAspectReadings(demoChart);
const audit = auditReport(demoChart, report);
export function NatalStudio() {
  const [unknown, setUnknown] = useState(false);
  const [feedback, setFeedback] = useState("");
  const [active, setActive] = useState("Sun");
  const [showDemo, setShowDemo] = useState(false);
  const [sectionIndex, setSectionIndex] = useState(0);
  function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    try {
      const birth = validateBirth({ date: data.get("date"), time: unknown ? null : data.get("time"), placeId: data.get("place"), consent: data.get("consent") === "on" });
      if (unknown) { setFeedback("Время неизвестно: асцендент и дома определять нельзя. Для запуска подготовим отдельный ограниченный формат. Сейчас доступен учебный пример, не связанный с твоими данными."); return; }
      const resolved = resolveBirthTime(birth);
      setFeedback(`Форма проверена. Часовой пояс: ${resolved.place.zone}; момент UTC: ${resolved.utc.replace("T", " ").slice(0, 16)}. ${resolved.precision !== "minute" ? "Историческая дата требует дополнительной проверки. " : ""}Персональный расчёт и оплата пока отключены. Данные никуда не отправлены и не сохранены. Пример ниже не является твоей картой.`);
    } catch (e) { setFeedback(e instanceof NatalError ? e.message : "Не удалось проверить форму. Попробуй ещё раз."); }
  }
  return <>
    <section className="shell natalStudio" id="natal-studio">
      <div className="natalFormCard"><span className="natalBadge">ПРОТОТИП · ОПЛАТА НЕ ОТКРЫТА</span><h2>Начнём с твоей<br /><em>точки рождения</em></h2><p>В полной версии эти данные станут основой расчёта. Сейчас форма проверяет ввод только в твоём браузере.</p>
        <form onSubmit={submit} onChange={() => setFeedback("")}>
          <label>Дата рождения<input name="date" type="date" min="1900-01-01" required /></label>
          <label className="natalCheck"><input type="checkbox" checked={unknown} onChange={e => setUnknown(e.target.checked)} />Не знаю точное время</label>
          <label>Местное время рождения<input name="time" type="time" disabled={unknown} required={!unknown} /><small>Из свидетельства или со слов близких. Не время в текущем часовом поясе.</small></label>
          <label>Город рождения<select name="place" required defaultValue=""><option value="" disabled>Выбери город</option>{places.map(p => <option value={p.id} key={p.id}>{p.name}</option>)}</select><small>Пока доступно 8 городов. Всемирный поиск добавим перед запуском.</small></label>
          <label className="natalCheck"><input name="consent" type="checkbox" required />Использую свои данные или имею разрешение их владельца.</label>
          <button className="button natalSubmit" type="submit">проверить данные →</button>
          <p className="natalFeedback" role="status" aria-live="polite">{feedback}</p>
        </form>
      </div>
      <aside className="natalPromise"><Image src="/aurora-cat.png" alt="Лунный кот Aurora" width={150} height={150} /><p className="eyebrow">ПОЛНЫЙ РАЗБОР / В РАЗРАБОТКЕ</p><h2>Не ярлык.<br /><em>Карта вопросов.</em></h2><p>Личность, эмоции, близость, действие и опора. У каждой интерпретации будет видно, какое положение карты лежит в её основе.</p><ul><li>Круг карты и таблица положений</li><li>10 тематических разделов</li><li>Аспекты и вопросы для саморефлексии</li><li>Версия для чтения и сохранения в PDF</li></ul><button type="button" className="button natalSubmit" onClick={() => setShowDemo(v => !v)} aria-expanded={showDemo} aria-controls="natal-demo">{showDemo ? "скрыть пример" : "посмотреть учебный пример"} ✦</button><small>Цена и дата запуска ещё не утверждены. Пример автоматизированный, не личная консультация Авроры.</small></aside>
    </section>
    {showDemo && <section className="shell natalReport" id="natal-demo"><div className="natalReportTop"><div><span className="natalBadge">УЧЕБНАЯ КАРТА · НЕ ПЕРСОНАЛЬНЫЙ РАСЧЁТ</span><h2>Маленькая вселенная<br /><em>внутри тебя</em></h2><p>Положения ниже заданы искусственно для демонстрации интерфейса. Они не рассчитаны по форме и не принадлежат реальному человеку. Трактовки — редакционный черновик, ожидающий проверки заказчицей.</p></div><button className="button natalPrint" type="button" onClick={() => window.print()}>печать / сохранить PDF ↗</button></div>
      <div className="natalMapGrid"><div className="natalWheel"><svg viewBox="0 0 440 440" role="img" aria-label="Учебный круг зодиака; точные положения представлены в таблице"><circle cx="220" cy="220" r="205" fill="#f6f0e8" stroke="#a99bc9" /><circle cx="220" cy="220" r="160" fill="none" stroke="#a99bc9" />{zodiac.map((name,i) => { const a = (i*30-75)*Math.PI/180; const edge=(i*30-90)*Math.PI/180; return <g key={name}><line x1={220+160*Math.cos(edge)} y1={220+160*Math.sin(edge)} x2={220+205*Math.cos(edge)} y2={220+205*Math.sin(edge)} stroke="#a99bc9" /><text x={220+182*Math.cos(a)} y={224+182*Math.sin(a)} textAnchor="middle" fontSize="10" fill="#3d2b53">{name}</text></g>; })}{aspects.map(a => { const pa=demoChart.placements.find(p=>p.planet===a.a)!;const pb=demoChart.placements.find(p=>p.planet===a.b)!;const angle=(n:number)=>(n-90)*Math.PI/180;return <line key={a.id} x1={220+130*Math.cos(angle(pa.longitude))} y1={220+130*Math.sin(angle(pa.longitude))} x2={220+130*Math.cos(angle(pb.longitude))} y2={220+130*Math.sin(angle(pb.longitude))} stroke="#a99bc9" opacity=".35" />; })}{demoChart.placements.map((p,i) => {const a=(p.longitude-90)*Math.PI/180; const radius=125-(i%2)*14;return <g key={p.planet}><circle cx={220+radius*Math.cos(a)} cy={220+radius*Math.sin(a)} r="13" fill={active===p.planet?"#3d2b53":"#cfc4e8"} /><text x={220+radius*Math.cos(a)} y={224+radius*Math.sin(a)} textAnchor="middle" fontSize="10" fill={active===p.planet?"#fff":"#3d2b53"}>{i+1}</text></g>;})}<text x="220" y="217" textAnchor="middle" fontSize="26" fill="#3d2b53">☾</text><text x="220" y="241" textAnchor="middle" fontSize="10" fill="#665184">AURORA / DEMO</text></svg></div><div className="natalPositions"><h3>Что лежит в основе</h3><p>Выбери планету — её положение подсветится на круге.</p>{report.map((r,i) => <button type="button" key={r.id} onClick={()=>setActive(demoChart.placements[i].planet)} aria-pressed={active===demoChart.placements[i].planet}><b>{i+1}. {planetNames[demoChart.placements[i].planet]}</b><span>{r.fact.split(": ")[1]}</span></button>)}</div></div>
      <aside className="natalAudit"><b>Проверка структуры пройдена: {audit.sections} из 10 разделов</b><p>Положения и ссылки сверены с учебными данными. Это не проверка астрономической точности или истинности трактовок.</p><small>{audit.chartVersion} · {audit.editorialVersion} · {audit.rulesVersion}</small></aside>
      <nav className="natalReadingNav" aria-label="Разделы разбора"><button type="button" onClick={()=>setSectionIndex(i=>i-1)} disabled={sectionIndex===0}>← предыдущий</button><span role="status">Раздел {sectionIndex+1} из {report.length}</span><button type="button" onClick={()=>setSectionIndex(i=>i+1)} disabled={sectionIndex===report.length-1}>следующий →</button></nav>
      <div className="natalReading">{report.map((r,i) => <article className={sectionIndex===i?"isActive":""} key={r.id}><p className="eyebrow">ОПОРА В КАРТЕ / {r.fact}</p><h3>{r.title}</h3><p>{r.text}</p><p className="natalHouseContext">{r.houseText}</p><blockquote>{r.question}</blockquote><small>Источник: {r.evidenceIds.join(", ")} · {r.editorialVersion}</small></article>)}</div>
      <article className="natalAspects"><h3>Связи между темами</h3><p>Это геометрические связи учебных положений, а не предсказания. Для прототипа орбисы: соединение, квадрат, трин и оппозиция — 6°; секстиль — 4°.</p><div className="natalAspectCards">{aspectReadings.map(a=><section key={a.id}><h4>{planetNames[a.a]} — {planetNames[a.b]}</h4><b>{a.name} · орбис {a.orb.toFixed(1)}°</b><p>{a.text}</p><small>Опора: {a.evidenceIds.join(" · ")}</small></section>)}</div></article><p className="natalDisclaimer">Астрология — интерпретационная практика, не научно подтверждённый способ предсказывать события. Этот материал не заменяет медицинскую, психологическую, юридическую или финансовую помощь. Решения остаются за тобой.</p>
    </section>}
  </>;
}
