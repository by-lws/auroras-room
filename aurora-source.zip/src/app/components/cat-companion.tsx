"use client";
import { useState } from "react";
import Image from "next/image";
import kitten from "./assets/aurora-kitten.webp";
import styles from "./cat-companion.module.css";
const thoughts = ["карты картами, а поесть?", "мур. ты на своей стороне.", "совет кота: сначала выдохни."];
export function CatCompanion() {
  const [count, setCount] = useState(0);
  return <div className={styles.companion}>
    <button type="button" className={styles.button} aria-label="Погладить кота" onClick={() => setCount(v => v + 1)}>
      <span key={count} className={`${styles.pose} ${count ? styles.petted : ""}`}>
        <Image className={styles.kitten} src={kitten} alt="Пушистый кремовый котик отдыхает, прикрыв глаза" sizes="(max-width: 760px) 140px, 180px" draggable={false}/>
        {count > 0 && <span className={styles.affection} aria-hidden="true">♡</span>}
      </span>
      <span className={styles.hint}>можно погладить</span>
    </button>
    <span key={`thought-${count}`} role="status" aria-live="polite" aria-atomic="true" className={`${styles.thought} ${count ? styles.shown : ""}`}>{count ? thoughts[(count - 1) % thoughts.length] : ""}</span>
  </div>;
}
