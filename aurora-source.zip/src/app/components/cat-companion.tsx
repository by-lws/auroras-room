"use client";
import { useState } from "react";
import { MoonCat } from "./aurora-art";
import styles from "./cat-companion.module.css";
const thoughts = ["карты картами, а поесть?", "мур. ты на своей стороне.", "совет кота: сначала выдохни."];
export function CatCompanion() {
  const [count, setCount] = useState(0);
  return <div className={styles.companion}><button type="button" className={styles.button} aria-label="Погладить кота" onClick={() => setCount(v => v + 1)}><MoonCat/><span className={styles.hint}>можно погладить</span></button><span key={count} role="status" className={`${styles.thought} ${count ? styles.shown : ""}`}>{count ? thoughts[(count - 1) % thoughts.length] : ""}</span></div>;
}
