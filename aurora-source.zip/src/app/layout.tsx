import type { Metadata } from "next";
import "@fontsource-variable/cormorant-garamond/wght.css";
import "@fontsource-variable/cormorant-garamond/wght-italic.css";
import "@fontsource-variable/manrope";
import "./globals.css";
import "./wine-theme.css";
import "./editorial.css";
import { ScrollReveal } from "./components/scroll-reveal";

export const metadata: Metadata = {
  metadataBase: new URL("https://xoxoaurora.ru"),
  title: {
    default: "Aurora’s room — Астрология и личные разборы",
    template: "%s — Aurora’s room",
  },
  description: "Пространство Авроры: экспресс-натал, релокация в один город и личные астрологические консультации.",
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    locale: "ru_RU",
    url: "/",
    siteName: "Aurora’s room",
    title: "Aurora’s room — Астрология и личные разборы",
    description: "Натальная карта, релокация и личные консультации Авроры.",
    images: [{ url: "/aurora-preview.png", width: 1200, height: 630, alt: "Лунный кот Aurora — Таро, ритуалы и возвращение к себе" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Aurora’s room",
    description: "Астрология и личные консультации Авроры",
    images: ["/aurora-preview.png"],
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ru">
      <body><ScrollReveal />{children}</body>
    </html>
  );
}
