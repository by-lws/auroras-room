// Deterministic export pipeline; ImageGen master remains untouched.
const fs = require('node:fs/promises');
const path = require('node:path');
const sharp = require(process.env.AURORA_SHARP_PATH || 'sharp');
const root = path.resolve(__dirname, '..');
async function main() {
  const p = path.join(root, 'public');
  const source = process.argv[2];
  if (!source) throw new Error('Provide ImageGen master PNG path');
  await fs.mkdir(path.join(root, 'brand'), { recursive: true });
  await fs.copyFile(source, path.join(root, 'brand/aurora-cat-master.png'));
  const meta = await sharp(source).metadata();
  if (!meta.hasAlpha || Math.min(meta.width, meta.height) < 1024) throw new Error('Master must have alpha and be at least 1024px');
  await sharp(source).resize(384, 384, {fit:'contain', background:'#00000000'}).png({palette:true,quality:90}).toFile(path.join(p, 'aurora-cat.png'));
  const vector = await fs.readFile(path.join(p, 'aurora-cat.svg'));
  const avatar = await sharp({create:{width:1024,height:1024,channels:4,background:'#cfc4e8'}}).composite([{input:await sharp(vector).resize(870,870).png().toBuffer(),left:77,top:77}]).png().toBuffer();
  await fs.writeFile(path.join(p,'aurora-avatar.png'), avatar);
  for (const size of [16,32,48,64,180,192,512]) {
    await sharp(avatar).resize(size,size).png().toFile(path.join(p,`aurora-icon-${size}.png`));
  }
  const mask = await sharp({create:{width:512,height:512,channels:4,background:'#cfc4e8'}}).composite([{input:await sharp(vector).resize(330,330).png().toBuffer(),left:91,top:91}]).png().toBuffer();
  await fs.writeFile(path.join(p,'aurora-maskable-512.png'),mask);
  const pngs = await Promise.all([16,32,48].map(s=>fs.readFile(path.join(p,`aurora-icon-${s}.png`))));
  const head=Buffer.alloc(6+16*pngs.length); head.writeUInt16LE(1,2); head.writeUInt16LE(pngs.length,4);
  let offset=head.length;
  pngs.forEach((b,i)=>{const pos=6+i*16,s=[16,32,48][i];head[pos]=s;head[pos+1]=s;head.writeUInt16LE(1,pos+4);head.writeUInt16LE(32,pos+6);head.writeUInt32LE(b.length,pos+8);head.writeUInt32LE(offset,pos+12);offset+=b.length;});
  await fs.writeFile(path.join(root,'src/app/favicon.ico'),Buffer.concat([head,...pngs]));
  await fs.copyFile(path.join(p,'aurora-icon-180.png'),path.join(root,'src/app/apple-icon.png'));
  const card = Buffer.from(`<svg width="1200" height="630" xmlns="http://www.w3.org/2000/svg"><rect width="1200" height="630" fill="#3d2b53"/><circle cx="1010" cy="420" r="280" fill="#665184"/><text x="75" y="140" fill="#cfc4e8" font-family="Georgia" font-size="22" letter-spacing="5">AURORA WORLD</text><text x="75" y="260" fill="#f6f0e8" font-family="Georgia" font-size="75" font-style="italic">aurora’s room</text><text x="80" y="340" fill="#ece3b4" font-family="Arial" font-size="30">Таро · ритуалы · возвращение к себе</text><text x="80" y="450" fill="#cfc4e8" font-family="Arial" font-size="25">Твой маленький лунный проводник</text><path d="M0 600Q100 490 220 600Q350 480 500 600Q650 520 820 610L1200 630H0Z" fill="#f6f0e8"/></svg>`);
  await sharp(card).composite([{input:await sharp(source).resize(440,520,{fit:'contain',background:'#00000000'}).png().toBuffer(),left:740,top:60}]).png().toFile(path.join(p,'aurora-preview.png'));
  console.log(JSON.stringify({master:meta.width+'×'+meta.height,alpha:meta.hasAlpha,exports:p}));
}
main().catch(e=>{console.error(e);process.exit(1)});
