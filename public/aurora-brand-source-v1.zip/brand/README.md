# Aurora lunar cat

Created with the built-in ImageGen tool on 2026-10-09. Transparent master: `aurora-cat-master.png`, 1254 × 1254 RGBA. Palette: cream #f6f0e8, lavender #a99bc9, plum #3d2b53, gold #ece3b4.

`public/aurora-cat.svg` is a deliberately simplified, manually redrawn vector portrait derived from the generated character, not a pixel-exact automatic trace. Use it at 16–64 px. Full illustration is `public/aurora-cat.png`; square avatar is `public/aurora-avatar.png`. Icon exports include 16, 32, 48, 64, 180, 192, 512 px, multi-size ICO and safe-area maskable 512 px. No offline service worker is installed; the manifest provides app identity, not offline functionality.

Re-export with `AURORA_SHARP_PATH=/path/to/sharp node scripts/build-mascot.cjs /path/to/aurora-cat-master.png`.

## Final ImageGen prompt

Use case: logo-brand. Create an original brand mascot for Aurora World / aurora’s room, a feminine grown-up tarot, inner-world and travel brand with vintage editorial lavender skies and cream clouds. A single cartoon CAT portrait / compact upper body, front view, huge readable silhouette for a 32px favicon. Pearl-cream fluffy round cat with distinctive asymmetric pointed ears, plum-purple thick clean outlines, half-lidded confident amused eyes, a cheeky gentle smile, tiny lavender nose. Signature mystical detail: one large lavender crescent on forehead, with a single cream-gold four-point star hanging from a plum collar. Tail curls like a small cloud at bottom right. Sophisticated hand-drawn flat vector-like illustration, restrained 4-color palette cream #f6f0e8 lavender #a99bc9 plum #3d2b53 gold #ece3b4. Memetic charm, warm sly personality, not babyish, not generic clipart. Centered in square 1024x1024 or larger, character occupies 86% width, ears wholly inside canvas, simple bold shapes, crisp contours, generous transparent margins. Genuine transparent background, no lettering, no hats, no wings, no shield, no VPN technology imagery, no other characters, no mockup, no shadows outside silhouette. This is the FINAL mascot artwork, not a sheet.

The supplied comparison photo IMG_8715.heic was not present at its requested local path; existing Aurora palette and project context were used. No existing brand mascot was copied.
